package ca.cours5b5.mathieubergeron.modeles;

import ca.cours5b5.mathieubergeron.donnees.Donnees;
import ca.cours5b5.mathieubergeron.vues.pages.PageAvecModeles;


public abstract class Modele <D extends Donnees, P extends PageAvecModeles> {

    protected D donnees;
    protected P page;

    public Modele(D donnees, P page){
        this.donnees = donnees;
        this.page = page;

        page.installerCapteurs(this);

    }

}
