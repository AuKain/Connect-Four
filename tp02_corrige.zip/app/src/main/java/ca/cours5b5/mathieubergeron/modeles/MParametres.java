package ca.cours5b5.mathieubergeron.modeles;

import ca.cours5b5.mathieubergeron.donnees.DParametres;
import ca.cours5b5.mathieubergeron.enumerations.ETailleGrille;
import ca.cours5b5.mathieubergeron.global.GLog;
import ca.cours5b5.mathieubergeron.vues.pages.PParametres;


public class MParametres extends Modele<DParametres, PParametres> {


    public MParametres(DParametres donnees, PParametres page) {
        super(donnees, page);
    }

    public void choisirTaille(ETailleGrille tailleGrille){
        GLog.appel(this);

        this.donnees.setTailleGrille(tailleGrille);

        this.page.rafraichirAffichage(this.donnees);

    }

    public void choisirSiContinuerPartie(boolean siContinuerPartie) {
        GLog.appel(this);

        this.donnees.setSiContinuerPartiePrecedente(siContinuerPartie);

        this.page.rafraichirAffichage(this.donnees);

    }
}
