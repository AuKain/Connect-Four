package ca.cours5b5.mathieubergeron.donnees;

public abstract class Donnees { }
