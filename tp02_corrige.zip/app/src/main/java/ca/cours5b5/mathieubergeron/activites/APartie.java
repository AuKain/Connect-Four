package ca.cours5b5.mathieubergeron.activites;

import ca.cours5b5.mathieubergeron.donnees.partie.DPartie;
import ca.cours5b5.mathieubergeron.modeles.MPartie;
import ca.cours5b5.mathieubergeron.vues.pages.PPartie;

public abstract class APartie<D extends DPartie, M extends MPartie, P extends PPartie> extends ActiviteAvecModeles<D,M,P> { }
