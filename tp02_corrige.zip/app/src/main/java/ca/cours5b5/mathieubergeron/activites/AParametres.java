package ca.cours5b5.mathieubergeron.activites;

import ca.cours5b5.mathieubergeron.R;
import ca.cours5b5.mathieubergeron.donnees.DParametres;
import ca.cours5b5.mathieubergeron.global.GLog;
import ca.cours5b5.mathieubergeron.modeles.MParametres;
import ca.cours5b5.mathieubergeron.vues.pages.PParametres;



public class AParametres extends ActiviteAvecModeles<DParametres, MParametres, PParametres> {

    @Override
    protected int getLayoutId() {
        GLog.appel(this);

        return R.layout.page_parametres;
    }

    @Override
    protected int getIdPage() {
        GLog.appel(this);

        return R.id.page_parametres;
    }

    @Override
    protected Class getClassDonnees() {
        GLog.appel(this);

        return DParametres.class;
    }

    @Override
    protected void creerModele(DParametres donnees, PParametres page) {
        GLog.appel(this);

        new MParametres(donnees, page);
    }

}
