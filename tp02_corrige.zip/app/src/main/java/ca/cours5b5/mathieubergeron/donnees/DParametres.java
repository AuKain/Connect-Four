package ca.cours5b5.mathieubergeron.donnees;

import javax.microedition.khronos.opengles.GL;

import ca.cours5b5.mathieubergeron.enumerations.ETailleGrille;
import ca.cours5b5.mathieubergeron.global.GConstantes;
import ca.cours5b5.mathieubergeron.global.GLog;

public class DParametres extends Donnees {


    private ETailleGrille tailleGrille = GConstantes.TAILLE_GRILLE_PAR_DEFAUT;
    private boolean siContinuerPartiePrecedente = GConstantes.SI_CONTINUER_PARTIE_PAR_DEFAUT;


    public ETailleGrille getTailleGrille() {
        GLog.appel(this);

        return tailleGrille;
    }

    public void setTailleGrille(ETailleGrille tailleGrille) {
        GLog.appel(this);

        this.tailleGrille = tailleGrille;
    }

    public boolean siContinuerPartiePrecedente() {
        GLog.appel(this);

        return siContinuerPartiePrecedente;
    }

    public void setSiContinuerPartiePrecedente(boolean siContinuerPartiePrecedente) {
        GLog.appel(this);
        this.siContinuerPartiePrecedente = siContinuerPartiePrecedente;
    }



}
