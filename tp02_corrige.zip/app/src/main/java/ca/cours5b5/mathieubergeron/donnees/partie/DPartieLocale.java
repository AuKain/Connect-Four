package ca.cours5b5.mathieubergeron.donnees.partie;

public class DPartieLocale extends DPartie {}
