package ca.cours5b5.mathieubergeron.enumerations;

import android.content.Context;
import ca.cours5b5.mathieubergeron.R;
import ca.cours5b5.mathieubergeron.global.GLog;

public enum ECouleur {

    JAUNE,
    ROUGE;

    public String getNomTraduit(Context context){
        GLog.appel(this);

        String nomTraduit = null;

        switch(this){

            case JAUNE:

                nomTraduit = context.getResources().getString(R.string.jaune);
                break;

            case ROUGE:

                nomTraduit = context.getResources().getString(R.string.rouge);
                break;

        }

        return nomTraduit;

    }
}
