package ca.cours5b5.mathieubergeron.donnees.partie;

import ca.cours5b5.mathieubergeron.enumerations.ECouleur;
import ca.cours5b5.mathieubergeron.global.GLog;

public class DCase {

    private ECouleur couleur;

    public ECouleur getCouleur() {
        GLog.appel(this);

        return couleur;
    }

    public void setCouleur(ECouleur couleur) {
        GLog.appel(this);

        this.couleur = couleur;
    }
}
