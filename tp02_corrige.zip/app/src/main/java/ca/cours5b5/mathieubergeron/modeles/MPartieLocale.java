package ca.cours5b5.mathieubergeron.modeles;

import ca.cours5b5.mathieubergeron.donnees.partie.DPartie;
import ca.cours5b5.mathieubergeron.vues.pages.PPartieLocale;

public class MPartieLocale extends MPartie {

    public MPartieLocale(DPartie donnees, PPartieLocale page) {
        super(donnees, page);
    }

}
